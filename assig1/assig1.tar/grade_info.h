#ifndef GRADE_INFO
#define GRADE_INFO
void grade_info(int grades[], int size);
#endif
