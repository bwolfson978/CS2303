/*Example C program for CS2303 Lab 1 */
#include <stdio.h>

int main() {
  int i; // Loop Counter

  printf("Hello, World!\n"); // Print a cheery greeting!

  /* This look print the numbers from 1 to 15, one per line. */
  for (i = 1; i <= 15; i++) {
    printf("%d\n", i); // Print the next number
  }

  printf("Goodbye!\n");
}
